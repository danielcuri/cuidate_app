import React, { useCallback, useRef, useState } from 'react';
import {
  FlatList,
  RefreshControl,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import type { StackNavigationProp } from '@react-navigation/stack';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { COLORS } from '../../theme/colors';
import { formService } from '../../services/FormService';
import { userService } from '../../services/UserService';
import { queryService } from '../../services/QueryService';
import { alertService } from '../../services/AlertService';
import type { RootStackParamList } from '../../navigation/AppNavigator';
import type { Forms } from '../../interfaces/forms';
import { useFormStore } from '../../stores/formStore';

type Nav = StackNavigationProp<RootStackParamList, 'Formats'>;

export function Formats() {
  const navigation = useNavigation<Nav>();
  const showPamolsa = useFormStore((s) => s.showPamolsa);
  const inspections = useFormStore((s) => s.inspections);
  const [refreshing, setRefreshing] = useState(false);
  const lastRefreshRef = useRef(0);

  const forms = (formService.forms as Forms[]) ?? [];

  const refreshList = useCallback(async () => {
    const uid = userService.user.id;
    if (uid == null) {
      return;
    }
    try {
      const res = (await formService.getFormatsList({ user_id: Number(uid) })) as {
        error?: boolean;
        forms?: Forms[];
      };
      if (res?.error) {
        queryService.manageErrors(res);
        return;
      }
      if (Array.isArray(res?.forms)) {
        formService.forms = res.forms;
        useFormStore.getState().syncFromService();
      }
    } catch (e) {
      console.log(e);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      void refreshList();
    }, [refreshList])
  );

  const onRefresh = async () => {
    const now = Date.now();
    if (now - lastRefreshRef.current < 2000) {
      return;
    }
    lastRefreshRef.current = now;
    setRefreshing(true);
    await refreshList();
    setRefreshing(false);
  };

  const openForm = (formId: number) => {
    navigation.navigate('CanvasForm', { formId });
  };

  const hallazgoFormId = (): number | null => {
    const ins = inspections as { form_id?: number; id?: number }[];
    if (!ins?.length) {
      return null;
    }
    const first = ins[0];
    return first.form_id ?? first.id ?? null;
  };

  const openHallazgo = () => {
    const fid = hallazgoFormId();
    if (fid == null) {
      alertService.present('Formatos', 'No hay formato de hallazgo SST disponible.');
      return;
    }
    openForm(fid);
  };

  return (
    <View style={styles.page}>
      <FlatList
        data={forms}
        keyExtractor={(f) => String(f.id)}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
        ListHeaderComponent={
          showPamolsa ? (
            <TouchableOpacity style={styles.hallazgo} onPress={openHallazgo} activeOpacity={0.88}>
              <Ionicons name="warning-outline" size={22} color={COLORS.white} />
              <Text style={styles.hallazgoTxt}>Hallazgo SST</Text>
              <Ionicons name="chevron-forward" size={20} color={COLORS.white} />
            </TouchableOpacity>
          ) : null
        }
        ListEmptyComponent={
          <Text style={styles.empty}>No hay formatos. Tire hacia abajo para actualizar.</Text>
        }
        renderItem={({ item }) => (
          <TouchableOpacity style={styles.row} onPress={() => openForm(item.id)} activeOpacity={0.88}>
            <Text style={styles.rowTitle} numberOfLines={2}>
              {String(item.name ?? item.id)}
            </Text>
            <Ionicons name="chevron-forward" size={20} color={COLORS.textMuted} />
          </TouchableOpacity>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  page: { flex: 1, backgroundColor: COLORS.menuContentBg },
  hallazgo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginHorizontal: 12,
    marginTop: 12,
    marginBottom: 8,
    padding: 14,
    borderRadius: 10,
    backgroundColor: COLORS.menuCardDark,
  },
  hallazgoTxt: { flex: 1, color: COLORS.white, fontWeight: '800', fontSize: 15 },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: 12,
    marginVertical: 4,
    padding: 16,
    backgroundColor: COLORS.white,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: COLORS.lightGray,
  },
  rowTitle: { flex: 1, fontSize: 15, fontWeight: '700', color: COLORS.text },
  empty: { textAlign: 'center', marginTop: 48, color: COLORS.textMuted, paddingHorizontal: 24 },
});
